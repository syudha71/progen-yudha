(defproject project "0.0.1-SNAPSHOT"
  :description "FIXME: write description"
  :dependencies [[org.clojure/clojure "1.9.0"]]
  :aot [project.core]
  :main project.core)
