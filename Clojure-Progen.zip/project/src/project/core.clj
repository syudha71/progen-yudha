(ns app.generator.yudha.arit
  (:require [clojure.set :as cset]))

(defn parti
  [num]
  (->> (str num)
       (into [])
       reverse
       (partition-all 3)
       (map #(apply str (reverse %)))
       (interpose ".")
       reverse
       (apply str)))

(defn rand+
  [x]
  (let [choices (->> (range (- x 3) (+ x 3))
                     (remove #(= x %))
                     shuffle
                     (take 4))]
    (zipmap [:p1 :p2 :p3 :p4] choices)))

(defn rand*
  [a b]
  (let [choices (->> (range (- a 2) (+ a 2))
                     (map #(* % b))
                     (concat (range (- (* a b) 3) (+ (* a b) 3)))
                     (remove #(= (* a b) %))
                     shuffle
                     distinct
                     (take 4))]
    (zipmap [:p1 :p2 :p3 :p4] choices)))

(defn arit-01
  []
  (->> (for [b (range 10 50)
             a (range (+ b 2) 50)
             blank [:a :b :c]]
         (let [ab a bb b cb (+ a b)
               mapi {:ab ab :bb bb :cb cb :a a :b b :c cb}]
           (condp = blank
             :a (merge mapi {:a "___" :pb a} (rand+ a))
             :b (merge mapi {:b "___" :pb b} (rand+ b))
             :c (merge mapi {:c "___" :pb cb} (rand+ cb)))))
       (shuffle)
       (take 100)))

(defn arit-02
  []
  (->> (for [a (range 2 20)
             b (range 1 10)]
         (let [pb (+ a b)]
           (merge {:a a :b b :pb pb}
                  (rand+ pb))))
       shuffle))

;;rata-rata 5 bilangan bulat
(defn arit-03
  []
  (->>  (fn []
          (let [[a b c d e] (shuffle (range 1 31))]
            (merge (zipmap [:a :b :c :d :e] [a b c d e]))
           {:check (mod (+ a b c d e) 5)
            :pb (quot (+ a b c d e) 5)}))

       (repeatedly 500)
       (filter #(zero? (:check %)))))

;;order of operations 
(defn arit-04
  []
  (->> (for [a (range 2 70)]
         (let [pb (+ a a (* a a) (/ a a))]
           (merge {:a a :pb pb}
                  (rand+ pb))))
       shuffle))

;;sifat distributif
(defn arit-05
  []
  (->> (for [a (range 2 10)
             b (range 2 10)
             c (range 2 15)]
         (let [pb (* a (+ b c))]
           (merge {:a a :b b :c c :pb pb}
                  (rand+ pb))))
       (shuffle)
       (take 100)))

;;sifat asosiatif dan komutatif
(defn arit-06
  []
  (->> (for [a (range 3 200)]
         ;;disini hati-hati, kadang tanda let [] kurang
         (let [b (- a 1) c (- a 2) d (+ a 5) e (+ a 6) f (+ a 7) pb (+ a b c d e f)]

              (merge {:a a :b b :c c :d d :e e :f f
                      :check (mod (+ a b c d e f) 5)
                      :pb pb}
                (rand+ pb))))
       (shuffle)
       (filter #(= (:check %) 0))
       (take 100)))

;;mencari nilai x untuk persamaan sederhana
(defn arit-07
  []
  (->> (for [a (filter even? (range 1 8))
             b (filter even? (range 2 100))
             c (filter even? (range 2 100))]
         (let [pb (/ (- c b) a)]
           (merge {:a a :b b :c c
                   :check (mod (/ (- c b) a) 2)
                   :pb pb}
                  (rand+ pb))))
       (shuffle)
       (filter #(= (:check %) 0))
       (take 100)))

;;Template Persen
(defn arit-08
 []
 (->> (for [a (range 1 100)
            b (range 1 100)]
        (let [pb (/ (* a b) 100)]
          (merge {:a a :b b 
                  :check (mod (/ (* a b) 100) 2)
                  :pb pb}
                 (rand+ pb))))
      (shuffle)
      (filter #(= (:check %) 0))
      (take 80)))

;;eksponen (hasilnya dalam bentuk angka)
(defn arit-09
 []
 (->> (for [a (range -5 12)
            b (range 2 5)]
        (let [pb (reduce * (repeat b a))]
          (merge {:a a :b b :pb pb}
                 (rand+ pb))))
      shuffle))
            
;;bentuk a^2-b^2= (a-b)(a+b). bisa juga modelling dikit
(defn arit-10
 []
 (->> (for [a (range 6 15)
            b (range 2 10)]
        (let [pb (* (+ a b) (- a b))
              c (+ a b) d (- a b)]
          (merge {:a a :b b :c c :d d 
                  :check (- a b)
                  :pb pb}
                 (rand+ pb))))
      (shuffle)
      (filter #(> (:check %) 0))))
      
;;order of operations 
(defn arit-11
  []
  (->> (for [a (range 2 50)]
         (let [pb (+ a (* a a) (/ a a))]
           (merge {:a a :pb pb}
                  (rand+ pb))))
       shuffle))
