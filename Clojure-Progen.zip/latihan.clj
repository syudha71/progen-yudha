(ns latihan)
(#(> % 5) [1 3 6 8])