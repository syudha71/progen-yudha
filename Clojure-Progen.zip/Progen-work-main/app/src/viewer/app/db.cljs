(ns app.db)

(def default-db
  {:data-register-message ""})
