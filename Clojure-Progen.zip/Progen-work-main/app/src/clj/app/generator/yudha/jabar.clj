(ns app.generator.yudha.jabar
  (:require 
   [clojure.set :as cset]
   [app.generator.yudha.arit :refer :all]))
  

;;(x-1)(x+10)=0 maka... ? a. x=1 atau x=-10 b. x=1 dan x=-10
(defn jabar-01 [] 
  (->> (fn []       
         (let [a (rand-nth (concat hurufa-d (range 0 20)))]    
           {:a (str "(x - " a ")(x + " a ")")   
            :pb (str "x = " a " atau x = -" a)   
            :p1 (str "x = " a " dan x = -" a)}))  
       (repeatedly 10)      
       (distinct)))
