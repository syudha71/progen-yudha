(ns app.generator.yudha.arit
  (:require [clojure.set :as cset]))
  
(defn parti
  [num]
  (->> (str num)
       (into [])
       reverse
       (partition-all 3)
       (map #(apply str (reverse %)))
       (interpose ".")
       reverse
       (apply str)))
  
(defn rand+
  [x]
  (let [choices (->> (range (- x 3) (+ x 3))
                     (remove #(= x %))
                     shuffle
                     (take 4))]
    (zipmap [:p1 :p2 :p3 :p4] choices)))
  
(defn rand*
  [a b]
  (let [choices (->> (range (- a 2) (+ a 2))
                     (map #(* % b))
                     (concat (range (- (* a b) 3) (+ (* a b) 3)))
                     (remove #(= (* a b) %))
                     shuffle
                     distinct
                     (take 4))]
    (zipmap [:p1 :p2 :p3 :p4] choices)))

  
  
  
(defn arit-02
  []
  (->> (for [a (range 2 20)
             b (range 1 10)]
         (let [pb (+ a b)]
           (merge {:a a :b b :pb pb}
             (rand+ pb))))
       (shuffle)
       (take 10)))
  
  ;;rata-rata 5 bilangan bulat
(defn arit-03
  []
  (->>  (fn []
          (let [[a b c d e] (shuffle (range 1 31))]
            (merge (zipmap [:a :b :c :d :e] [a b c d e])
              {:check (mod (+ a b c d e) 5)
               :pb (quot (+ a b c d e) 5)})))
       
       (repeatedly 5)
       (filter #(zero? (:check %)))))
  
  ;;order of operations 
(defn arit-04
  []
  (->> (for [a (range 2 70)]
         (let [pb (+ a a (* a a) (/ a a))]
           (merge {:a a :pb pb}
             (rand+ pb))))
       shuffle))
  
  ;;sifat distributif
(defn arit-05
  []
  (->> (for [a (range 2 10)
             b (range 2 10)
             c (range 2 15)]
         (let [pb (* a (+ b c))]
           (merge {:a a :b b :c c :pb pb}
             (rand+ pb))))
       (shuffle)
       (take 10)))
  
  ;;sifat asosiatif dan komutatif
(defn arit-06
  []
  (->> (for [a (range 3 100)]
         ;;disini hati-hati, kadang tanda let [] kurang
         (let [b (- a 1) c (- a 2) d (+ a 5) e (+ a 6) f (+ a 7) pb (+ a b c d e f)
               g (+ a d)]
           
           (merge {:a a :b b :c c :d d :e e :f f :g g
                   :check (mod (+ a b c d e f) 5)
                   :pb pb}
             (rand+ pb))))
       (shuffle)
       (filter #(= (:check %) 0))
       (take 5)))
  
  ;;mencari nilai x untuk persamaan sederhana
(defn arit-07
  []
  (->> (for [a (filter even? (range 1 8))
             b (filter even? (range 2 100))
             c (filter even? (range 2 100))]
         (let [pb (/ (- c b) a) d (- c b)]
           (merge {:a a :b b :c c :d d
                   :check (mod (/ (- c b) a) 2)
                   :pb pb}
             (rand+ pb))))
       (shuffle)
       (filter #(= (:check %) 0))
       (take 10)))
  
  ;;Template Persen
(defn arit-08
  []
  (->> (for [a (range 1 100)
             b (range 1 100)]
         (let [pb (/ (* a b) 100)]
           (merge {:a a :b b 
                   :check (mod (/ (* a b) 100) 2)
                   :pb pb}
             (rand+ pb))))
       (shuffle)
       (filter #(= (:check %) 0))
       (take 10)))
  
  ;;eksponen (hasilnya dalam bentuk angka) 
(defn arit-09
  []
  (->> (for [a (range -5 5)
             b (range 2 5)]
         (let [pb (reduce * (repeat b a))]
           (merge {:a a :b b :pb pb}
             (rand+ pb))))
       shuffle))
              
  ;;bentuk a^2-b^2= (a-b)(a+b). bisa juga modelling dikit
(defn arit-10
  []
  (->> (for [a (range 6 15)
             b (range 2 10)]
         (let [pb (* (+ a b) (- a b))
               c (+ a b) d (- a b) e (* a a) f (* b b)]
           (merge {:a a :b b :c c :d d :e e :f f
                   :check (- a b)
                   :pb pb}
             (rand+ pb))))
       (shuffle)
       (filter #(> (:check %) 0))))
        
  ;;order of operations (opsinya sudah ganti)
(defn arit-11  [] 
  (->> (for [a (range 2 30)]    
         (let [pb (+ a (* a a) (/ a a))   
               p1 (* (+ (/ (+ a a) a) a) a) 
               p2 (+ a a (* a a) (/ a a))  
               p3 (* (/ (+ a a) (+ a a) a))
               p4 (+ pb 1)] 
           {:a a :pb pb :p1 p1 :p2 p2 :p3 p3 :p4 p4}))
       shuffle))
    
  
  ;;4x19 = 4x(20-1)
(defn arit-12
  []
  (->> (for [a (range 2 10)
             b (range 15 20)]
         (let [pb (* a b) c (reduce max (range 21)) d (- c b) e (* a c) f (* a d)]
           (merge {:a a :b b :c c :d d :e e :f f :pb pb}
             (rand+ pb))))
       (shuffle)
       (take 10)))
  
  ;;definisi eksponen 8^3 = 8 x 8 x 8
(defn arit-13  
  []  
  (->> (fn [] 
         (let [a (rand-nth (range 5 10))  
               b (rand-nth(range 2 4))]  
           (merge {:a a :b b}       
             (condp = b        
               2 {:pb (str a " x " a)   
                  :p1 (str a "+" a)       
                  :p2 (str a "+" a "+" a)    
                  :p3 (str a " x " a " x " a)   
                  :p4 (str a " x " b)}        
               3 {:pb (str a " x " a " x " a)   
                  :p1 (str a "+" a "+" a)   
                  :p2 (str a " x " a)         
                  :p3 (str a "+" a)         
                  :p4 (str a " x " b)}))))    
       (repeatedly 20)     
       shuffle))
  
  ;;y=x^2, jika y = 9, maka x = 3
(defn arit-14  [] 
  (->> (for [a (range 2 11)]      
         (let [b (reduce * (repeat 2 a))   
               pb (str (- a) " atau " a)    
               p1 (str (- a) " dan " a)
               p2 (- a)]         
           {:a a :b b :pb pb :p1 p1 :p2 p2}))    
       (shuffle)))
  
  ;; \sqrt sesuatu adalah ...
(defn arit-15  [] 
  (->> (for [a (range 2 11)]      
         (let [b (reduce * (repeat 2 a)) 
               p1 (str (- a) " atau " a)]          
           {:a a :b b :pb a :p1 p1}))    
       (shuffle)
       (take 10)))
 
  ;; \sqrt (-x)^2 adalah ...
(defn arit-16  [] 
  (->> (for [a (range -20 0)]      
         (let [b (reduce * (repeat 2 a))
               pb (- a)
               p1 (str (- a) " atau " a)    
               p2 (str (- a) "i")        
               p3 a
               p4 (str "Tidak dapat ditentukan")]          
           {:a a :b b :pb pb :p1 p1 :p2 p2 :p3 p3 :p4 p4}))    
       (shuffle)
       (take 10)))
  
  ;;Postulat 1, bentuk kesamaan isi dan formasi
(defn bilbul?
  [num] 
  (zero? (rem num 1)))
  
(defn kuadratsempurna?
  [x]
  (bilbul? (Math/sqrt x)))
  
(defn arit-17 
  []  
  (->> (for [a (remove kuadratsempurna? (range 1 15))]   
         (let [p1 (* 2 a)            
               p2 (str "Ada 2 pilihan yang benar")]   
           {:a a :p1 p1 :p2 p2}))          
       (shuffle)
       (take 10)))
  
  ;;True or false (8 ÷ 4) ÷ 2 = 8 ÷ (4 ÷ 2) Asosiatif komutatif dalam pembagian
  ;;catatan -> cari yg hasil baginya adalah bilangan bulat
(defn arit-18     
  []     
  (->> (for [c (filter even? (range 1 40))]    
         (let [b (* 2 c)           
               a (* 2 b)       
               d (/ a b)       
               e (/ b c)       
               s1 (/ d c)    
               s2 (/ a e)]       
           {:a a :b b :c c :d d :e e :s1 s1 :s2 s2})) 
       (shuffle)
       (take 10))) 

;;□ + a = b --> □ - a = ...
(defn arit-19
  []
  (->> (fn []  
         (let [a (rand-nth (range 1 20))      
               b (rand-nth (range 20 30))]   
           {:a a :b b :c (- b a) :pb (- (- b a) a) :p1 (+ (- b a) a)   
            :p2 (+ (- b a) a 1) :p3 (- b) :p4 (- b a)})) 
       (repeatedly 10)))


;;Pembagian pecahan --> Kesalahan: kalo pembagian pecahan, harus di balik pecahannya
(defn arit-20  []    
  (->> (for [a (range 2 11)] 
         (let [b (* a a)]        
           {:a a :b b}))      
       (shuffle)))

;;P = a x b, maka -P = ... 
(defn arit-21  []    
  (->> (for [a (range 2 11)
             b (range 2 11)] 
         (let [pb (str (- a) " x " b)
               p1 (str (- a) " x " (- b))]        
           {:a a :b b :pb pb :p1 p1}))      
       (shuffle)
       (take 10)))

;;P = (a + b), maka -P = ... 
(defn arit-22  []    
  (->> (for [a (range 2 6)
             b (range 2 6)] 
         (let [p1 (str (- (* 2 a)) " + " (* 2 b))
               pb (str (- (* 2 a)) " + (" (- (* 2 b)) ")")]        
           {:a a :b b :pb pb :p1 p1}))      
       (shuffle)
       (take 10)))

;;Jebakan definisi eksponen 8 + 8 + 8 = ...? 8^3
(defn arit-23  
  []  
  (->> (fn [] 
         (let [a (rand-nth (range 5 10))  
               b (rand-nth(range 3 5))]  
           (merge {:a a :b b}       
             (condp = b        
               3 {:c (str a " + " a " + " a)    
                  :d (str b " x " a)
                  :e (str a " x " a " x " a)}        
               4 {:c (str a " + " a " + " a " + " a)   
                  :d (str b " x " a)
                  :e (str a " x " a " x " a " x " a)}))))    
       (repeatedly 20)     
       shuffle))

;;(-a)^2 = -a^2
(defn arit-24 
  []  (->> (fn []  
             (let [a (rand-nth (range -10 0)) 
                   b (rand-nth (range 2 4))]
               (merge {:a a :b b}  
                 (condp = b        
                   2 {:p1 "benar"   
                      :pb "salah"
                      :c (str "(" a ") x (" a ")")
                      :d (reduce * (repeat b a))
                      :e (str  a " x " (- a))
                      :f (* a (- a))}   
                   3 {:p1 "salah"     
                      :pb "benar"
                      :c (str "(" a ") x (" a ") x (" a ")")
                      :d (reduce * (repeat b a))
                      :e (str a " x " (- a) " x " (- a))
                      :f (* a (- a) (- a))}))))  
           (repeatedly 10)))

;; -3(-3) = ... a. 9 b. -6

