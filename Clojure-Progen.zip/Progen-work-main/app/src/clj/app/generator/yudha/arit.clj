(ns app.generator.yudha.arit
  (:require [clojure.set :as cset]))
  


;;list huruf a-d
(def hurufa-d (->> (range (int \a) 
                     (inc (int \d)))
                   (map char)
                   (map str)))
;;list huruf p-s
(def huruf-p (->> (range (int \p) 
                    (inc (int \s)))
                  (map char)
                  (map str)))

;; -3(-3) = ... a. 9 b. -6
(defn arit-25 []    
  (->> (fn []              
         (let [a (rand-nth (concat hurufa-d (range -10 0)))]  
           (if (string? a) {:a (str "-" a)    
                            :pb (str a "<sup>2</sup>")  
                            :p1 (str (- 2) a)}         
             {:a a :pb (* a a) :p1 (+ a a)})))      
       (repeatedly 10)
       (distinct)))


;; -3^2-(-3)^2 = ... a. 0 b. -2.3^2
(defn arit-26 []  
  (->> (fn []      
         (let [a (rand-nth (concat huruf-p (range -10 0)))] 
           (if (string? a) {:a (str "-" a)   
                            :pb (str (- 2) a "<sup>2</sup>")  
                            :p1 0}               
             {:a a :pb (- (- (reduce * (repeat 2 a))) (reduce * (repeat 2 a))) 
              :p1 0})))           
       (repeatedly 10)      
       (distinct)))

;; barang x di diskon 20% trus dikenakan pajak 20%, harganya jadi harga semula? 
(defn arit-27  [] 
  (->> (for [a ["jam tangan" "kacamata" "pulpen" "botol minum"
                "buku matematika" "buku UTBK Zenius" "Jarsey MU" "Smartphone"] 
             b (range 1 50)
             c (range 1000 10000 500)]      
         {:a a :b b :c c})     
       (shuffle)      
       (take 10)      
       (distinct)))

;; barang x didiskon 80% trus didiskon lagi 20%, total diskonnya jadi 100%?
(defn arit-28  []
  (->> (for [a ["jam tangan" "kacamata" "pulpen" "botol minum"        
                "buku matematika" "buku UTBK Zenius" "Jarsey MU" "Smartphone"]  
             b (range 1 51)     
             c (range 1 51)]         
         {:a a :b b :c c :p1 (+ b c)   
          :pb (- 100 (/ (* (- 100 b) (- 100 c)) 100))  
          :check (rem (* (- 100 b) (- 100 c)) 100)})    
       (filter #(= (:check %) 0))   
       (take 10)))

;; a% dari b > < atau = b% dari a
(defn arit-29  []  
  (->> (for [a (range 20 51)  
             b (range 1 101)]  
         {:a (str a "% dari " b)      
          :b (str b "% dari " a)  
          :pb (str " = ")      
          :p1 (str " ≠ ")      
          :check (mod b 10)})  
       (shuffle)   
       (filter #(= (:check %) 0)) 
       (remove #(= (:a %) (:b %1))) 
       (take 10)))
