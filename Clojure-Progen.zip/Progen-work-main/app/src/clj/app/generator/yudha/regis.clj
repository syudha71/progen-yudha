(ns app.generator.yudha.regis
  (:require [app.generator.yudha.arit]
            [app.generator.yudha.jabar]))


(def register
  [{:folder "math-aritmetik"
    :file   "arit-29.html"
    :topic  :math
    :gen-fn app.generator.yudha.arit/arit-29}
   {:folder "math-jabar"
    :file   "jabar-01.html"
    :topic  :math
    :gen-fn app.generator.yudha.jabar/jabar-01}])
