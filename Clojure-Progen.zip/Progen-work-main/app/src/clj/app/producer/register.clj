(ns app.producer.register
  (:require
    [app.generator.sbd.regis :as sbd]
    [app.generator.cania.regis :as cania]
    [app.generator.yudha.regis :as yudha]))

(defn soal-map
  "Register each folder"
  []
  (concat sbd/register cania/register yudha/register))


