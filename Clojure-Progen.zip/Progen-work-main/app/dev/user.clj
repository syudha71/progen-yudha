(ns user
  (:require
    [app.viewersys.system :as viewersys]
    [com.stuartsierra.component :as component]
    [app.utils :refer :all]))

(defonce dev-system (atom nil))

;;===== SYSTEM RELATED FUNCTIONS ======

(defn start
  "Starting the viewer, produce or not produce"
  [& [mode]]
  (->> (viewersys/create-system (if mode mode :viewer))
       (component/start-system)
       (reset! dev-system)))

(defn stop []
  (swap! dev-system component/stop-system))

(defn restart
  []
  (let [mode (:mode @dev-system)]
    (do (stop)
        (print "Restarting the system in 2 seconds... ")
        (Thread/sleep 100)
        (println "plus/minus 5 minutes.")
        (Thread/sleep 100)
        (start mode))))

































