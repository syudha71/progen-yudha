# progen-work
Progen for collab works..

### Where to begin?

* Open this code from green button "code" and choose "open on desktop"
* Copy file config-template.edn to the same folder (this file located on app/resources)
* Change the name to config.edn located on 
* Run repl and start with (start)
* Goto localhost:4000 on browser


#### How to create templatess

* Change the config.edn using the same pattern and use your own name
* Create the folders as desribed in config (with your own name)
* All templates put on template folder
* All generators on generator folder
* You need to register your generator and template

#### Using image in templates

* Use uuid generator website to get a UUID number
* Save the file in folder resources/public/img in format "<uuid>.jpg" or "<uuid>.png" according to original file
* Use :image-xxx keyword in your generator function as key for this image, and the filename as value
* You can use more than one image per template

#### Generating problems

* To start producing problem, use repl and put (start :generate)


